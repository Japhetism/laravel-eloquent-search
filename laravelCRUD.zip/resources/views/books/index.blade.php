@extends('layouts.default')
@section('content')
<a class="btn btn-sm btn-info pull-right" href="{{url('/books/new')}}">New Book</a><br/><br/><br/>
@if (session('message'))
    <div class="alert alert-success">
        <strong>Success!</strong> {{ session('message') }}.
    </div>
@endif 
<table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
            <th>Name</th>
            <th>Edition</th>
            <th>Cost(&#8358;)</th>
            <th>Pages</th>
            <th>Date Added</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($books as $book)
            <tr>
                <td>{{$book->name}}</td>
                <td>{{$book->edition}}</td>
                <td>{{$book->cost}}</td>
                <td>{{$book->pages}}</td>
                <td>{{$book->created_at->toDayDateTimeString()}}</td>
                <td>
                <a class="btn btn-xs btn-primary" href='{{url("/books/$book->id")}}'>View</a>
                    <a class="btn btn-xs btn-warning" href='{{url("/books/$book->id/edit")}}'>Edit</a>
                    <a class="btn btn-xs btn-danger" href='{{url("/books/$book->id/delete")}}'>Remove</a>
                </td>
            </tr>
        @endforeach                   
    </tbody>
</table>
@endsection