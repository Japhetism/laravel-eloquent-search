<?php $__env->startSection('content'); ?>
<a class="btn btn-sm btn-info pull-right" href="<?php echo e(url('/books/new')); ?>">New Book</a><br/><br/><br/>
<?php if(session('message')): ?>
    <div class="alert alert-success">
        <strong>Success!</strong> <?php echo e(session('message')); ?>.
    </div>
<?php endif; ?> 
<table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
            <th>Name</th>
            <th>Edition</th>
            <th>Cost(&#8358;)</th>
            <th>Pages</th>
            <th>Date Added</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($book->name); ?></td>
                <td><?php echo e($book->edition); ?></td>
                <td><?php echo e($book->cost); ?></td>
                <td><?php echo e($book->pages); ?></td>
                <td><?php echo e($book->created_at->toDayDateTimeString()); ?></td>
                <td>
                <a class="btn btn-xs btn-primary" href='<?php echo e(url("/books/$book->id")); ?>'>View</a>
                    <a class="btn btn-xs btn-warning" href='<?php echo e(url("/books/$book->id/edit")); ?>'>Edit</a>
                    <a class="btn btn-xs btn-danger" href='<?php echo e(url("/books/$book->id/delete")); ?>'>Remove</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>