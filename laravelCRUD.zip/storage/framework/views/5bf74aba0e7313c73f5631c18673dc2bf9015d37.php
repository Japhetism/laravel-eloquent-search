<?php $__env->startSection('content'); ?>
<div class="col-md-offset-3 col-md-6">  
    <div class="pull-right">
        <a class="btn btn-xs btn-warning" href='<?php echo e(url("/books/$book->id/edit")); ?>'>Edit</a>&nbsp;&nbsp;<a class="btn btn-xs btn-danger" href="#">Remove</a>   
    </div>
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Name:</label>
        <h4><span><?php echo e($book->name); ?></span></h4>
        <hr/>
        <br/>
    </div>
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Edition:</label>
        <h4><span><?php echo e($book->edition); ?></span></h4>
        <hr/>
        <br/>
    </div>
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Cost(&#8358;):</label>
        <h4><span><?php echo e($book->cost); ?></span></h4>
        <hr/>
        <br/>
    </div>
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Pages:</label>
        <h4><span><?php echo e($book->pages); ?></span></h4>
        <hr/>
        <br/>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>