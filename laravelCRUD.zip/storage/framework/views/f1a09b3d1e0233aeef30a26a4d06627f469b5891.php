<?php $__env->startSection('content'); ?>
<div class="col-md-offset-3 col-md-6">
<form method="post" action="<?php echo e(url('/books/new')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="recipient-name" class="col-form-label">Name:</label>
            <input type="text" class="form-control" name="name" placeholder="SpiderMan" required/>
        </div>
        <div class="form-group">
            <label for="recipient-name" class="col-form-label">Edition:</label>
            <input type="text" class="form-control" name="edition" placeholder="10th Edition" required/>
        </div>
        <div class="form-group">
            <label for="recipient-name" class="col-form-label">Cost(&#8358;):</label>
            <input type="text" class="form-control" name="cost" placeholder="3400" required/>
        </div>
        <div class="form-group">
            <label for="recipient-name" class="col-form-label">Pages:</label>
            <input type="number" class="form-control" name="pages" placeholder="40" required/>
        </div>
        <button class="btn btn-primary pull-right" type="submit">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>