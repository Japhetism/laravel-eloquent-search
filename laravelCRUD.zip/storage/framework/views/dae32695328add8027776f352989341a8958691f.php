<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <a style="text-decoration:none;" href="<?php echo e(url('/books')); ?>"><h2>Jarfluect Shelf</h2></a><br/><br/>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>